<?php
function emptyFilds($arg) //$_POST
{
    if (!is_array($arg)) {
        print "The argument must be an array";
        return false;
    }

    foreach ($arg as $k => $v) {
        if (empty($v)) {
            print "<b>" . ucwords($k) . "</b>
            must not be empty. Please click the browser back button and correct it.";
            return false;
        }
    }
    return true;
}

function cleanString($str)
{
    $str = trim($str);
    $str = htmlspecialchars($str);
    $str = addslashes($str);
    return $str;
}

function isEligible($skills, $age)
{
    $age = intval($age);
    if (count($skills) == 0) {
        print "You dont have any skills";
        return false;
    }
    if ($age < 22 || $age > 35) {
        print("Your age must be between 22 and 35 years");
        return false;
    }
    return true;
}



if (!emptyFilds($_POST)) {
    exit();
}

$name = cleanString($_POST['name']);
$phone = cleanString($_POST['phone']);
$email = cleanString($_POST['email']);
$address = cleanString($_POST['address']);
$gender = $_POST['gender'];
$city = $_POST['city'];
$age = (int) cleanString($_POST['age']);
$skills = $_POST['skills'];

if (!isEligible($skills, $age)) {
    exit("You are not eligible to Apply");
}

print "<h4>Thank you " . $name . " for submitting, We 'll contact you soon!</h4>";
print "We recived your following information <br>";
print "Name: " . $name . "<br>";
print "Phone: " . $phone . "<br>";
print "Email: " . $email . "<br>";
print "Address: " . $address . "<br>";
print "Gender: " . $gender . "<br>";
print "City: " . $city . "<br>";
print "Age: " . $age . "<br>";
print "Your Skills: ";
foreach ($skills as $skill) {
    print $skill . ",";
}












// if (isset($_POST['submit'])) {
//     echo $name = $_POST['name'];
//     echo $phone = $_POST['phone'];
//     echo $email = $_POST['email'];
//     echo $address = $_POST['address'];
//     echo $gender = $_POST['gender'];
//     echo $city = $_POST['city'];
//     echo $age = $_POST['age'];
//     $skills = $_POST['skills'];
//     var_dump($skills);
// }
